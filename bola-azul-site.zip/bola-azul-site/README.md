# Voz do Povo Esportes — site com notícias do dia

O site busca as manchetes do dia **toda vez que a página abre e a cada clique em "Recarregar notícias"**.
Ele precisa de hospedagem com função de servidor. O passo a passo abaixo usa o Netlify (grátis).

## O que ele usa
- **Notícias:** manchetes do Google Notícias (últimas 24 horas; se houver poucas, 3 dias), com link para a matéria original.
- **Tabela, jogos da semana, artilharia e assistências:** football-data.org (plano gratuito).

## Passo a passo
1. **Chave da API de futebol.** Crie uma conta grátis em https://www.football-data.org/client/register e copie o token que chega por e-mail.
   Confira na página de planos se o plano gratuito inclui o "Campeonato Brasileiro Série A" (código BSA).
2. **Suba os arquivos no GitHub.** Crie um repositório e envie esta pasta inteira (incluindo `netlify/functions/dados.js`, `netlify.toml` e `index.html`).
3. **Publique no Netlify.** Em https://app.netlify.com escolha *Add new site → Import an existing project*, selecione o repositório e confirme (não precisa mudar nada).
4. **Coloque a chave.** No Netlify: *Site configuration → Environment variables → Add a variable*. Nome: `FOOTBALL_DATA_KEY`. Valor: o token do passo 1.
   Depois faça *Deploys → Trigger deploy*.
5. **Abra o endereço do site** que o Netlify mostrar.

## Como testar a função
Abra no navegador (troque pelo seu endereço):
- `/.netlify/functions/dados?tipo=noticias&q=Flamengo` → deve listar manchetes.
- `/.netlify/functions/dados?tipo=tabela` → deve listar os 20 clubes.
Se aparecer `{"erro": ...}`, a mensagem diz o que falta.

## Limites
- A tabela, os jogos e a artilharia vêm só do Brasileirão. Copa do Brasil, Sul-Americana e Série B aparecem como notícias.
- As assistências consideram os 50 maiores artilheiros do campeonato.
- O Google Notícias é para uso pessoal e não comercial; as manchetes sempre levam à matéria original.
- Sem fotos dos jogos: elas pertencem aos veículos. Os cartões usam o escudo dos clubes citados na manchete.

## Personalizar
- No começo do arquivo `app.js`, troque `contato@seusite.com.br` pelo seu e-mail (aparece em "Contato", "Envie sua pauta" e no rodapé).
- Os quadros "Anuncie aqui" são espaços para anunciantes: troque o texto por uma imagem com link.

## Conteúdo salvo no site (dentro do `index.html`)
- **Destaques da redação:** manchete e matérias com texto completo (abrem ao clicar), vindas do site anterior (dados de 25/10/2026).
- **Temporada 2026:** Brasileirão, Libertadores, Copa do Brasil, Sul-Americana, Série B e Copa do Mundo.
- **Painel do time:** linha "Outras competições em 2026".
- **Plano B:** se a API de tabela, jogos ou artilharia falhar (por exemplo, antes de colocar a chave), o site mostra esses dados salvos, com aviso.
- Esse conteúdo não se atualiza sozinho. Só as manchetes do bloco "Últimas notícias" são buscadas a cada clique. Para renovar o arquivo, peça ao Claude.

## Se as notícias derem erro
- **Não abra o `index.html` com duplo clique.** A função de servidor só existe no site publicado. Mesmo assim, o site tenta buscar as manchetes por um serviço público alternativo; se ele estiver fora do ar, aparece o aviso.
- Se publicou no Netlify e ainda dá erro, abra `https://SEU-SITE.netlify.app/.netlify/functions/dados?tipo=noticias`. A mensagem que aparecer ali diz o que está errado (me envie, se precisar).
- Confira se a pasta `netlify/functions/dados.js` foi enviada ao GitHub com esse caminho exato.

## Criar matérias com o Blogger do Google
O site mostra as matérias que você escrever num blog do Blogger, sem precisar mexer em código.
1. Acesse https://www.blogger.com com sua conta Google e clique em **Criar blog**. Nome: Voz do Povo Esportes. Escolha o endereço (por exemplo `vozdopovoesportes.blogspot.com`).
2. No blog, abra **Configurações → Feed do site** e escolha **Completo** (assim o texto inteiro chega ao site).
3. Clique em **Nova postagem**: escreva o título e o texto, adicione fotos pelo botão de imagem, e em **Marcadores** coloque o assunto, por exemplo `Brasileirão`, `Libertadores`, `Copa do Brasil`, `Sul-Americana`, `Série B` ou o nome do time (`Palmeiras`). Clique em **Publicar**.
4. No Netlify: **Site configuration → Environment variables → Add a variable**. Nome: `BLOGGER_URL`. Valor: o endereço do blog com https, por exemplo `https://vozdopovoesportes.blogspot.com`. Faça um novo deploy.
5. Pronto: as matérias aparecem em **Matérias** no topo do site, e abrem dentro do próprio site ao clicar. O marcador com o nome de um campeonato filtra pelo menu, e o marcador com o nome de um time coloca a matéria no painel desse time.
Enquanto o blog não tiver matérias (ou a variável não existir), o site mostra os "Destaques da redação" salvos.

## Como atualizar os arquivos no GitHub
Abra o repositório, entre na pasta do arquivo, clique em **Add file → Upload files**, envie o arquivo novo (mesmo nome) e confirme com **Commit changes**. O Netlify publica sozinho em alguns segundos. Para `dados.js`, entre antes em `netlify/functions`.

## Notícias novas e importantes primeiro
- **Só o que é recente:** as manchetes ficam limitadas às últimas 48 horas (se houver poucas, 96 horas). Matérias do Blogger com mais de 7 dias saem da tela, e os "Destaques da redação" salvos somem sozinhos depois de 2 dias.
- **Ordem:** a mesma notícia publicada por vários veículos é agrupada num só cartão, que mostra "N veículos". A ordem leva em conta quantos veículos deram o assunto, a data, palavras de peso (final, título, elimina, rebaixamento, lidera, virada etc.) e veículos conhecidos.
- **Você decide o que é manchete:** no Blogger, use o marcador `Destaque` (ou `Manchete`) numa matéria e ela vai para o topo.

## Fotos
- **Matérias do Blogger:** usam as fotos que você colocar na postagem (use fotos suas ou licenciadas).
- **Manchetes de outros veículos:** o site tenta trazer a miniatura da matéria pelo Bing Notícias. Nem toda notícia vem com foto; quando não vem (ou a imagem não carrega), aparece o campo com o escudo dos times. As fotos pertencem aos veículos e o cartão sempre leva à matéria original. Se o site for comercial, confirme os direitos de uso.

## Conteúdo próprio, dentro do site (sem redirecionar)
- **Matérias do Blogger:** textos e fotos seus (ou licenciados). Abrem dentro do site.
- **Resumo do jogo:** textos originais gerados automaticamente só com fatos (placar, rodada, posição na tabela) dos jogos dos últimos 3 dias, a partir do football-data.org. Aparecem identificados como "Resumo do jogo" e abrem dentro do site. Exigem a variável `FOOTBALL_DATA_KEY`.
- **Veja também em outros veículos:** só manchete e link. O texto e as fotos pertencem a cada veículo, e o clique leva ao site de origem. As fotos de terceiros ficam desligadas (`fotos:false` no começo do arquivo `app.js`).

## Atenção legal
- Copiar o texto completo de outros sites para o seu sem autorização viola direitos autorais. Por isso o site não faz isso.
- A Agência Brasil (EBC) informa "todos os direitos reservados" e, nos termos de uso, limita o uso do portal a fins pessoais sem intuito comercial. Para republicar o conteúdo, peça autorização à EBC.
- O football-data.org tem regras próprias para uso comercial no plano gratuito. Confira os termos antes de vender anúncios.
- Este texto não é aconselhamento jurídico; em caso de dúvida, consulte um advogado.

## Propaganda no site
**1) Anunciantes diretos (como no Voz do Povo)** — você vende o espaço e fica com 100%.
- Salve o banner do anunciante na pasta `anuncios/` do repositório (faixa do topo ~240×60 px; coluna lateral 300×250 px).
- No começo do arquivo `app.js`, preencha `ANUNCIOS`, por exemplo:
  `topo:[{img:"anuncios/padaria.png",link:"https://wa.me/5542999999999",alt:"Padaria Central"}]`
- O site mostra até 5 anunciantes no topo e até 3 na lateral; os espaços sem anunciante exibem "Anuncie aqui" (leva ao seu e-mail). Todos aparecem com a palavra "Publicidade". Combine valores e prazo por escrito com cada anunciante.

**2) Google AdSense (anúncios automáticos)**
- Requisitos: ter 18 anos ou mais, conteúdo próprio de qualidade e seguir as políticas do Google; ter domínio próprio (um endereço `.netlify.app` costuma ser recusado); ter páginas Sobre, Contato e Política de Privacidade (há um modelo em `privacidade.html`: preencha os dados entre colchetes).
- Passos: registre um domínio (por exemplo no Registro.br) e ligue-o ao Netlify; crie a conta em adsense.google.com e cadastre o site; coloque seu código `ca-pub-...` em `SITE.adsense`, no começo do arquivo `app.js`; depois da aprovação, crie na raiz do repositório o arquivo `ads.txt` com a linha que o AdSense indicar (formato: `google.com, pub-XXXXXXXXXXXXXXXX, DIRECT, f08c47fec0942fa0`).
- A análise leva de alguns dias a semanas. O Google exige conteúdo original: quanto mais matérias suas (Blogger), melhor.

## Páginas do site (como no ge)
- `index.html`: só notícias (matérias suas, resumos de jogos e "Veja também"), com filtro por campeonato.
- `tabela.html`: classificação completa do Brasileirão (P, J, V, E, D, GP, GC, SG e aproveitamento). Cada clube leva ao painel do time.
- `jogos.html`: jogos e resultados por rodada (escolha a rodada na lista).
- `artilharia.html`: artilheiros e líderes de assistências.
- `temporada.html`: Libertadores, Copa do Brasil, Sul-Americana, Série B e Copa do Mundo (também abre direto num campeonato: `temporada.html?c=Libertadores`).
- `times.html`: painel do time (estatísticas, notícias, artilheiros e outras competições), por exemplo `times.html?t=Palmeiras`.
- Arquivos compartilhados: `estilo.css` (visual), `app.js` (funcionamento), `dados-fixos.js` (dados salvos), `logo.png` e `favicon.png`.
- **Ao atualizar no GitHub, envie todos esses arquivos juntos** (Add file → Upload files, mesmo nome, Commit). As páginas dependem uns dos outros.
